#include <fmt/format.h>
#include <hv/Event.h>
#include <hv/EventLoop.h>
#include <spdlog/common.h>
#include <spdlog/spdlog.h>

#include <cstdlib>
#include <cxxopts.hpp>
#include <optional>
#include <string>

#include "agent/agent.h"

void Setup(thuai7_agent::Agent& agent);
void Loop(thuai7_agent::Agent& agent);

struct Options {
  std::string server;
  std::string token;
};

constexpr auto kDefaultServer = "ws://localhost:14514";
constexpr auto kDefaultToken = "1919810";
constexpr auto kLoopInterval = 100;  // In milliseconds.

auto ParseOptions(int argc, char** argv) -> std::optional<Options> {
  std::string server{kDefaultServer};
  std::string token{kDefaultToken};
  // NOLINTBEGIN(concurrency-mt-unsafe)
  if (auto const* env_server = std::getenv("SERVER_ADDRESS")) {
    server = env_server;
  }
  if (auto const* env_token = std::getenv("TOKEN")) {
    token = env_token;
  }
  // NOLINTEND(concurrency-mt-unsafe)

  cxxopts::Options options("agent");
  options.add_options()("server", "Server address",
                        cxxopts::value<std::string>()->default_value(server))(
      "token", "Agent token",
      cxxopts::value<std::string>()->default_value(token))("h,help",
                                                           "Print usage");
  auto result = options.parse(argc, argv);

  if (result.count("help") > 0) {
    std::cout << options.help() << std::endl;
    return std::nullopt;
  }

  server = result["server"].as<std::string>();
  token = result["token"].as<std::string>();

  return Options{
      .server = server,
      .token = token,
  };
}

auto main(int argc, char* argv[]) -> int {
#ifdef NDEBUG
  spdlog::set_level(spdlog::level::info);
#else
  spdlog::set_level(spdlog::level::debug);
#endif

  auto options = ParseOptions(argc, argv);
  if (!options.has_value()) {
    return 0;
  }

  hv::EventLoopPtr event_loop = std::make_shared<hv::EventLoop>();

  thuai7_agent::Agent agent(options->token, event_loop, kLoopInterval);

  spdlog::info("{} is starting with server {}", agent, options->server);

  event_loop->runInLoop([&] { agent.Connect(options->server); });

  bool is_previous_connected = false;
  bool is_previous_game_ready = false;
  bool is_setup = false;

  event_loop->setInterval(kLoopInterval, [&](hv::TimerID) {
    // Check connection status.
    if (!agent.IsConnected()) {
      if (is_previous_connected) {
        spdlog::error("{} is disconnected", agent);
        is_previous_connected = false;
      }
      spdlog::debug("{} is waiting for connection", agent);
      return;
    }

    if (!is_previous_connected) {
      spdlog::info("{} is connected", agent);
      is_previous_connected = true;
    }

    // Check game ready status.
    if (!agent.IsGameReady()) {
      if (is_previous_game_ready) {
        spdlog::error("{} is no longer in a ready game", agent);
        is_previous_game_ready = false;
      }
      spdlog::debug("{} is waiting for the game to be ready", agent);
      return;
    }

    if (!is_previous_game_ready) {
      spdlog::info("{} is in a ready game", agent);
      is_previous_game_ready = true;
    }

    // Setup agent if not done yet.
    if (!is_setup) {
      Setup(agent);
      spdlog::info("{} is setup", agent);
      is_setup = true;
    }

    Loop(agent);
  });
  
  event_loop->run();

  return 0;
}
/*void Setup(thuai7_agent::Agent& agent) {
  int loop =0;
  thuai7_agent::SupplyKind weapon_;
  thuai7_agent::SafeZone safezone_=agent.safe_zone().value().get();
  thuai7_agent::Position<float> SpwanPoint;
  do{
    if (loop==0)weapon_=thuai7_agent::SupplyKind::kAwm;
    else if (loop==1)weapon_=thuai7_agent::SupplyKind::kM16;
    else if (loop==2)weapon_=thuai7_agent::SupplyKind::kVectory;
    else if (loop==3)weapon_=thuai7_agent::SupplyKind::kS686;
    else if (loop==4)weapon_=thuai7_agent::SupplyKind::kPremiumArmor;
    else if (loop==5)weapon_=thuai7_agent::SupplyKind::kPrimaryArmor;
    std::vector<thuai7_agent::Position<float>> supply_position;
    for (auto& supply : agent.supplies().value().get()) {
      if (supply.kind == weapon_
      && pow(safezone_.center.x-supply.position.x,2)
      +pow(safezone_.center.y-supply.position.y,2) <pow(safezone_.radius-30,2)) {
        supply_position.push_back(supply.position);
      }
    }
    if (supply_position.size()!=0){
      float min=256*256;
        for(auto supply_pos:supply_position){
          float dis=pow(safezone_.center.x - supply_pos.x,2)+pow(safezone_.center.y- supply_pos.y,2);
          if (dis < min) {
            min = dis;
            SpwanPoint=supply_pos;
          }
        }
        loop =-1;
    }
      spdlog::debug("looping");
  }while(loop++!=-1);
        thuai7_agent::Position<float> origin_pos{SpwanPoint.x,
                                                SpwanPoint.y};
        agent.ChooseOrigin(origin_pos);
      spdlog::debug("done");
  // Your code here.
}*/