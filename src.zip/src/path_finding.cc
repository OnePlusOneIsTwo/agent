#include "path_finding.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <functional>
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "agent/position.h"

static auto CalculateManhattanDistance(thuai7_agent::Position<int> const& start,
                                       thuai7_agent::Position<int> const& end)
    -> int;
static auto GetNeighbors(thuai7_agent::Map const& map,
                         thuai7_agent::Position<int> const& position)
    -> std::vector<thuai7_agent::Position<int>>;
static auto IsValidPosition(thuai7_agent::Map const& map,
                            thuai7_agent::Position<int> const& position)
    -> bool;

auto FindPathBeFS(thuai7_agent::Map const& map,
                  thuai7_agent::Position<int> const& start,
                  thuai7_agent::Position<int> const& end)
    -> std::vector<thuai7_agent::Position<int>> {
  auto priority_queue_comparator =
      [&end](thuai7_agent::Position<int> const& lhs,
             thuai7_agent::Position<int> const& rhs) -> bool {
    return CalculateManhattanDistance(lhs, end) >
           CalculateManhattanDistance(rhs, end);
  };
  auto unordered_set_hasher =
      [](thuai7_agent::Position<int> const& position) -> std::size_t {
    return std::hash<int>{}(position.x) ^ std::hash<int>{}(position.y);
  };

  std::priority_queue<thuai7_agent::Position<int>,
                      std::vector<thuai7_agent::Position<int>>,
                      decltype(priority_queue_comparator)>
      queue(priority_queue_comparator);

  std::unordered_set<thuai7_agent::Position<int>,
                     decltype(unordered_set_hasher)>
      visited(0, unordered_set_hasher);

  std::unordered_map<thuai7_agent::Position<int>, thuai7_agent::Position<int>,
                     decltype(unordered_set_hasher)>
      parents(0, unordered_set_hasher);

  queue.push(start);
  visited.insert(start);

  bool is_found = false;

  while (!queue.empty() && !is_found) {
    auto current = queue.top();
    queue.pop();

    if (current == end) {
      is_found = true;
      break;
    }

    for (auto const& neighbor : GetNeighbors(map, current)) {
      if (visited.find(neighbor) != visited.end()) {
        continue;
      }

      queue.push(neighbor);
      visited.insert(neighbor);
      parents[neighbor] = current;
    }
  }

  if (!is_found) {
    return {};
  }

  std::vector<thuai7_agent::Position<int>> path;
  for (auto current = end; current != start; current = parents[current]) {
    path.push_back(current);
  }
  path.push_back(start);

  std::reverse(path.begin(), path.end());

  return path;
}

static auto CalculateManhattanDistance(thuai7_agent::Position<int> const& start,
                                       thuai7_agent::Position<int> const& end)
    -> int {
  return std::pow(start.x - end.x,2) + std::pow(start.y - end.y,2);
}

static auto GetNeighbors(thuai7_agent::Map const& map,
                         thuai7_agent::Position<int> const& position)
    -> std::vector<thuai7_agent::Position<int>> {
  std::array<thuai7_agent::Position<int>, 4> neighbors{
      thuai7_agent::Position<int>{position.x - 1, position.y},
      thuai7_agent::Position<int>{position.x + 1, position.y},
      thuai7_agent::Position<int>{position.x, position.y - 1},
      thuai7_agent::Position<int>{position.x, position.y + 1},
  };

  std::vector<thuai7_agent::Position<int>> valid_neighbors;
  for (auto const& neighbor : neighbors) {
    if (IsValidPosition(map, neighbor)) {
      valid_neighbors.push_back(neighbor);
    }
  }

  return valid_neighbors;
}

static auto IsValidPosition(thuai7_agent::Map const& map,
                            thuai7_agent::Position<int> const& position)
    -> bool {
  for (auto const& obstacle : map.obstacles) {
    if (position == obstacle) {
      return false;
    }
  }

  return position.x >= 0 && position.x < map.length && position.y >= 0 &&
         position.y < map.length;
}
float arctan(float x, float y){
    if (x==0&&y==0)return -1;
    else if (x==0&&y>0)return 3.1415926/2;
    else if (x==0&&y<0)return 3.1415926*3/2;
    else if (x>0&&y>=0)return atan(y/x);
    else if (x>0)return 2*3.1415926 + atan(y/x);
    else if (y>=0)return 3.1415926+atan(y/x);
    else return 3.1415926+atan(y/x);
}
bool BulletCollision(thuai7_agent::Map map,
                  thuai7_agent::Position<float> ini,
                  thuai7_agent::Position<float> end){
    thuai7_agent::Position<int> pos_int;
    pos_int.x=(int)ini.x;
    pos_int.y=(int)ini.y;
    if ((int)ini.x==ini.x&&end.x-ini.x<0)pos_int.x--;
    if ((int)ini.y==ini.y&&end.y-ini.y<0)pos_int.y--;
    float theta = arctan(end.x-ini.x,end.y-ini.y);
    if ((int)end.x==end.x&&end.x-ini.x>0)end.x--;
    if ((int)end.y==end.y&&end.y-ini.y>0)end.y--;
    int last_side=-1;//last_side 检测回头路
    if (!IsValidPosition(map,pos_int))return false;
    while (pos_int.x!=(int)end.x||pos_int.y!=(int)end.y){
        thuai7_agent::Position<int>p1=pos_int;
        thuai7_agent::Position<int>p2{pos_int.x+1,pos_int.y};
        thuai7_agent::Position<int>p3{pos_int.x,pos_int.y+1};
        thuai7_agent::Position<int>p4{pos_int.x+1,pos_int.y+1};
        float p1_t=arctan((float)p1.x-ini.x,(float)p1.y-ini.y);
        float p2_t=arctan((float)p2.x-ini.x,(float)p2.y-ini.y);
        float p3_t=arctan((float)p3.x-ini.x,(float)p3.y-ini.y);
        float p4_t=arctan((float)p4.x-ini.x,(float)p4.y-ini.y);//判断四个点到初始点的角度
        if (p1_t==theta&&last_side!=11){//检测角情况
            pos_int.x--;
           if (!IsValidPosition(map,pos_int))return false;
            pos_int.x++;
            pos_int.y--;
           if (!IsValidPosition(map,pos_int))return false;
            pos_int.x--;
            last_side=14;
        }else if (p2_t==theta&&last_side!=12){
            pos_int.x++;
           if (!IsValidPosition(map,pos_int))return false;
            pos_int.x--;
            pos_int.y--;
           if (!IsValidPosition(map,pos_int))return false;
            pos_int.x++;
            last_side=13;
        }else if (p3_t==theta&&last_side!=13){
            pos_int.x--;
           if (!IsValidPosition(map,pos_int))return false;
            pos_int.x++;
            pos_int.y++;
           if (!IsValidPosition(map,pos_int))return false;
            pos_int.x--;
            last_side=12;
        }else if (p4_t==theta&&last_side!=14){
            pos_int.x++;
           if (!IsValidPosition(map,pos_int))return false;
            pos_int.x--;
            pos_int.y++;
           if (!IsValidPosition(map,pos_int))return false;
            pos_int.x++;
            last_side=11;
        }else if (p4_t<theta&&theta<p3_t&&last_side!=4){//检测边情况
            last_side=1;
            pos_int.y++;
        }else if (p3_t<theta&&theta<p1_t&&last_side!=2){
            last_side=3;
            pos_int.x--;
        }else if (p1_t<theta&&theta<p2_t&&last_side!=1){
            last_side=4;
            pos_int.y--;
        }else{
            last_side=2;
            pos_int.x++;
        }
        if (!IsValidPosition(map,pos_int))return false;
    }
    return true;
}
